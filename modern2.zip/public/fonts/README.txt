Place your custom font files here for the multilingual site:

- K24KurdishBold.ttf
- AbdoMaster-DemiBold.ttf

The code already references these paths:
/public/fonts/K24KurdishBold.ttf
/public/fonts/AbdoMaster-DemiBold.ttf

I did not bundle the font binaries into the output ZIP.
