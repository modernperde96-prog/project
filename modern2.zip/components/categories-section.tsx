"use client"

import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

const categories = [
  {
    id: 1,
    tag: "Signature",
    title: "Luxury Curtains",
    description: "Statement fabrics for elegant living spaces.",
    image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=900&q=80",
    tall: true,
  },
  {
    id: 2,
    tag: "Soft Light",
    title: "Sheer Collection",
    description: "Airy layers that keep your room bright and refined.",
    image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 3,
    tag: "Privacy",
    title: "Blackout Fabrics",
    description: "Deep coverage for bedrooms, offices and media rooms.",
    image: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 4,
    tag: "Systems",
    title: "Rails, hardware & accessories",
    description: "Modern tracks, brackets, rings and finishing details that complete the look.",
    isAccent: true,
    wide: true,
  },
]

export function CategoriesSection() {
  return (
    <section id="categories" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 text-sm uppercase tracking-wider text-primary font-medium"
            >
              <span className="w-8 h-px bg-primary" />
              Shop by category
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl md:text-4xl font-serif font-bold mt-3"
            >
              Everything for a complete curtain solution
            </motion.h2>
          </div>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-muted-foreground max-w-md"
          >
            A premium storefront experience for fabric, rails, accessories and custom room styling.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {categories.map((category, index) => (
            <motion.article
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "group relative overflow-hidden rounded-3xl",
                category.tall && "md:row-span-2",
                category.wide && "md:col-span-2",
                category.isAccent
                  ? "bg-gradient-to-br from-primary/30 to-primary/5 min-h-[200px]"
                  : "min-h-[280px]"
              )}
            >
              {category.image && (
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                  style={{ backgroundImage: `url(${category.image})` }}
                />
              )}
              
              {!category.isAccent && (
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              )}

              <div className="relative z-10 h-full flex flex-col justify-end p-6">
                <span className={cn(
                  "text-sm font-medium mb-2",
                  category.isAccent ? "text-primary" : "text-primary-foreground/80"
                )}>
                  {category.tag}
                </span>
                <h3 className={cn(
                  "text-xl md:text-2xl font-bold mb-2",
                  category.isAccent ? "text-foreground" : "text-white"
                )}>
                  {category.title}
                </h3>
                <p className={cn(
                  "text-sm max-w-md",
                  category.isAccent ? "text-muted-foreground" : "text-white/80"
                )}>
                  {category.description}
                </p>
                
                {category.isAccent && (
                  <a
                    href="#collections"
                    className="inline-flex items-center gap-2 mt-4 text-sm font-semibold text-primary hover:gap-3 transition-all"
                  >
                    Browse products
                    <ArrowRight className="h-4 w-4" />
                  </a>
                )}
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}
