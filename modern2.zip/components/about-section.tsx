import Link from 'next/link'
import { Award, Layers3, Sparkles, LayoutGrid } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dictionary, Locale, localizePath } from '@/lib/i18n'

const icons = [Award, Layers3, Sparkles, LayoutGrid]

export function AboutSection({ locale, dict, compact = false }: { locale: Locale; dict: Dictionary; compact?: boolean }) {
  return (
    <section id="about" className="bg-secondary/35 py-24">
      <div className="container mx-auto px-4">
        <div className="grid items-center gap-12 lg:grid-cols-[1fr_1.05fr]">
          <div className="grid grid-cols-2 gap-4">
            <img
              src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80"
              alt="Modern curtain showroom"
              className="aspect-[4/5] h-full w-full rounded-[1.8rem] object-cover"
            />
            <div className="space-y-4 pt-10">
              <div className="rounded-[1.8rem] border border-border bg-card p-6 shadow-sm">
                <p className="text-sm uppercase tracking-[0.18em] text-primary">Modern Perde</p>
                <p className="mt-3 text-lg font-semibold">{dict.home.about.body1}</p>
              </div>
              <img
                src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=900&q=80"
                alt="Fabric selection"
                className="aspect-[4/5] h-full w-full rounded-[1.8rem] object-cover"
              />
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">{dict.home.about.eyebrow}</p>
            <h2 className="mt-3 text-3xl font-serif font-bold md:text-4xl">{compact ? dict.home.about.title : dict.pages.about.title}</h2>
            <p className="mt-5 text-lg leading-8 text-muted-foreground">{compact ? dict.home.about.body1 : dict.pages.about.description}</p>
            <p className="mt-5 text-lg leading-8 text-muted-foreground">{compact ? dict.home.about.body2 : dict.pages.about.story[0]}</p>

            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {dict.home.about.stats.map((stat, index) => {
                const Icon = icons[index] ?? Sparkles
                return (
                  <div key={stat.label} className="rounded-[1.4rem] border border-border bg-card p-5 shadow-sm">
                    <Icon className="h-5 w-5 text-primary" />
                    <span className="mt-4 block text-3xl font-bold">{stat.value}</span>
                    <span className="text-sm text-muted-foreground">{stat.label}</span>
                  </div>
                )
              })}
            </div>

            <div className="mt-8 flex flex-wrap gap-4">
              <Button asChild className="rounded-full px-6">
                <Link href={localizePath(locale, '/contact')}>{dict.home.cta.primary}</Link>
              </Button>
              <Button asChild variant="outline" className="rounded-full px-6">
                <Link href={localizePath(locale, '/about')}>{dict.nav.about}</Link>
              </Button>
            </div>
          </div>
        </div>

        {!compact ? (
          <div className="mt-14 grid gap-5 md:grid-cols-3">
            {dict.pages.about.story.map((item) => (
              <div key={item} className="rounded-[1.5rem] border border-border bg-card p-6 shadow-sm">
                <p className="leading-7 text-muted-foreground">{item}</p>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </section>
  )
}
