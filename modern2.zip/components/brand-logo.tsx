import Image from 'next/image'
import Link from 'next/link'
import { cn } from '@/lib/utils'

interface BrandLogoProps {
  showText?: boolean
  compact?: boolean
  className?: string
  href?: string
  tagline?: string
}

export function BrandLogo({
  showText = true,
  compact = false,
  className,
  href = '/',
  tagline = 'Curtains • Rails • Custom Design',
}: BrandLogoProps) {
  const content = (
    <div className={cn('flex items-center gap-3', className)}>
      <div className={cn('relative overflow-hidden rounded-2xl border border-border/60 bg-card shadow-sm', compact ? 'h-11 w-11' : 'h-14 w-14')}>
        <Image src="/modern-perde-logo.png" alt="Modern Perde logo" fill sizes={compact ? '44px' : '56px'} className="object-cover" priority />
      </div>

      {showText && (
        <div className="min-w-0">
          <span className="block truncate text-lg font-bold leading-none">Modern Perde</span>
          <span className="mt-1 block truncate text-xs text-muted-foreground">{tagline}</span>
        </div>
      )}
    </div>
  )

  return <Link href={href}>{content}</Link>
}
