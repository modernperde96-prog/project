"use client"

import Image from "next/image"
import { AnimatePresence, motion } from "framer-motion"
import { usePathname, useSearchParams } from "next/navigation"
import { useEffect, useMemo, useRef, useState } from "react"

function shouldShowLoader(anchor: HTMLAnchorElement) {
  const href = anchor.getAttribute("href")
  if (!href) return false
  if (href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) return false
  if (anchor.target === "_blank" || anchor.hasAttribute("download")) return false

  const url = new URL(href, window.location.href)
  if (url.origin !== window.location.origin) return false

  const samePage =
    url.pathname === window.location.pathname &&
    url.search === window.location.search &&
    (url.hash === window.location.hash || url.hash !== "")

  return !samePage
}

export function PageTransitionLoader() {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const currentLocation = useMemo(() => `${pathname}?${searchParams.toString()}`, [pathname, searchParams])
  const [isLoading, setIsLoading] = useState(true)
  const hasMountedRef = useRef(false)
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    timeoutRef.current = setTimeout(() => setIsLoading(false), 1200)
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
    }
  }, [])

  useEffect(() => {
    if (!hasMountedRef.current) {
      hasMountedRef.current = true
      return
    }

    setIsLoading(true)
    if (timeoutRef.current) clearTimeout(timeoutRef.current)
    timeoutRef.current = setTimeout(() => setIsLoading(false), 700)
  }, [currentLocation])

  useEffect(() => {
    const handleClick = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0) return
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return

      const target = event.target as HTMLElement | null
      const anchor = target?.closest("a") as HTMLAnchorElement | null
      if (!anchor) return
      if (!shouldShowLoader(anchor)) return

      setIsLoading(true)
    }

    document.addEventListener("click", handleClick, true)
    return () => document.removeEventListener("click", handleClick, true)
  }, [])

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          key="page-loader"
          initial={{ opacity: 1 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.35 }}
          className="pointer-events-none fixed inset-0 z-[120] flex items-center justify-center bg-background/96 backdrop-blur-xl"
        >
          <div className="relative flex flex-col items-center px-6 text-center">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.96, opacity: 0 }}
              transition={{ duration: 0.35 }}
              className="relative mb-6 h-28 w-28 overflow-hidden rounded-[2rem] border border-border bg-card shadow-2xl shadow-primary/10"
            >
              <Image
                src="/modern-perde-logo.png"
                alt="Modern Perde"
                fill
                priority
                sizes="112px"
                className="object-cover"
              />
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-2xl font-serif font-bold"
            >
              Modern Perde
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.08 }}
              className="mt-2 max-w-sm text-sm text-muted-foreground"
            >
              Loading the next page with your brand splash screen.
            </motion.p>

            <div className="mt-6 flex items-center gap-3">
              <span className="block h-2.5 w-2.5 animate-pulse rounded-full bg-primary" />
              <span className="block h-2.5 w-2.5 animate-pulse rounded-full bg-primary [animation-delay:0.2s]" />
              <span className="block h-2.5 w-2.5 animate-pulse rounded-full bg-primary [animation-delay:0.4s]" />
            </div>

            <div className="mt-6 h-1.5 w-56 overflow-hidden rounded-full bg-secondary">
              <motion.div
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.2, ease: "easeInOut" }}
                className="h-full w-1/2 rounded-full bg-primary"
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
