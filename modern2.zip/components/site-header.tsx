"use client"

import Link from 'next/link'
import { useEffect, useMemo, useState } from 'react'
import { usePathname } from 'next/navigation'
import { ChevronDown, Globe, Menu, Moon, Sun, UserRound, X } from 'lucide-react'
import { useTheme } from 'next-themes'
import { motion, AnimatePresence } from 'framer-motion'
import { BrandLogo } from '@/components/brand-logo'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'
import { Dictionary, Locale, localeInfo, localizePath, getDir } from '@/lib/i18n'

interface SiteHeaderProps {
  locale: Locale
  dict: Dictionary
}

function localizedHref(locale: Locale, href: string) {
  if (href.startsWith('/#')) return localizePath(locale) + href.slice(1)
  if (href === '/') return localizePath(locale)
  return localizePath(locale, href)
}

function switchLocalePath(pathname: string, nextLocale: Locale) {
  const segments = pathname.split('/').filter(Boolean)
  if (segments.length === 0) return `/${nextLocale}`
  segments[0] = nextLocale
  return `/${segments.join('/')}`
}

export function SiteHeader({ locale, dict }: SiteHeaderProps) {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const dir = getDir(locale)

  useEffect(() => {
    setMounted(true)
  }, [])

  const directLinks = useMemo(
    () => [
      { label: dict.nav.home, href: localizePath(locale) },
      { label: dict.nav.collections, href: localizedHref(locale, '/collections') },
      { label: dict.nav.rails, href: localizedHref(locale, '/rails') },
      { label: dict.nav.partners, href: localizedHref(locale, '/partners') },
      { label: dict.nav.team, href: localizedHref(locale, '/team') },
      { label: dict.nav.about, href: localizedHref(locale, '/about') },
      { label: dict.nav.contact, href: localizedHref(locale, '/contact') },
    ],
    [dict, locale],
  )

  return (
    <>
      <div className="bg-foreground text-background">
        <div className="container mx-auto flex flex-wrap items-center justify-between gap-3 px-4 py-2 text-sm">
          <span className="text-background/85">{dict.topBar}</span>
          <div className="hidden items-center gap-2 md:flex">
            <Globe className="h-4 w-4" />
            <span className="text-background/70">{dict.languageLabel}</span>
            <div className="flex items-center gap-1">
              {(Object.entries(localeInfo) as [Locale, (typeof localeInfo)[Locale]][]).map(([key, info]) => (
                <Link
                  key={key}
                  href={switchLocalePath(pathname, key)}
                  className={cn(
                    'rounded-full px-3 py-1 text-xs transition-colors',
                    key === locale ? 'bg-primary text-primary-foreground' : 'bg-white/5 hover:bg-white/10',
                  )}
                >
                  {info.nativeLabel}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/90 backdrop-blur-xl">
        <div className="container mx-auto px-4">
          <nav className="flex min-h-20 items-center justify-between gap-4">
            <BrandLogo href={localizePath(locale)} compact />

            <div className="hidden items-center gap-2 lg:flex">
              <HeaderDropdown locale={locale} title={dict.nav.shopDropdown} menu={dict.menu.shop} />
              <HeaderDropdown locale={locale} title={dict.nav.pagesDropdown} menu={dict.menu.pages} />
              {directLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    'rounded-full px-4 py-2 text-sm font-medium transition-colors hover:bg-secondary hover:text-primary',
                    pathname === link.href ? 'bg-secondary text-primary' : 'text-foreground/85',
                  )}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full" aria-label={dict.accountLabel}>
                    <UserRound className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align={dir === 'rtl' ? 'start' : 'end'} className="w-56 rounded-2xl p-2">
                  <DropdownMenuLabel>{dict.accountLabel}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href={localizedHref(locale, '/login')} className="cursor-pointer rounded-xl">
                      {dict.login}
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href={localizedHref(locale, '/signup')} className="cursor-pointer rounded-xl">
                      {dict.signup}
                    </Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {mounted ? (
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full"
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                  aria-label="Toggle theme"
                >
                  {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>
              ) : null}

              <Button
                variant="ghost"
                size="icon"
                className="rounded-full lg:hidden"
                onClick={() => setMobileOpen((value) => !value)}
                aria-label="Toggle menu"
              >
                {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </nav>
        </div>

        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden border-t border-border/60 lg:hidden"
            >
              <div className="container mx-auto space-y-6 px-4 py-5">
                <MobileGroup locale={locale} title={dict.nav.shopDropdown} items={dict.menu.shop.items ?? []} onClose={() => setMobileOpen(false)} />
                <MobileGroup locale={locale} title={dict.nav.pagesDropdown} items={dict.menu.pages.items ?? []} onClose={() => setMobileOpen(false)} />

                <div className="grid gap-2">
                  {directLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setMobileOpen(false)}
                      className="rounded-2xl border border-border bg-card px-4 py-3 font-medium"
                    >
                      {link.label}
                    </Link>
                  ))}
                </div>

                <div className="grid gap-2 sm:grid-cols-2">
                  <Button asChild variant="outline" className="rounded-2xl">
                    <Link href={localizedHref(locale, '/login')} onClick={() => setMobileOpen(false)}>
                      {dict.login}
                    </Link>
                  </Button>
                  <Button asChild className="rounded-2xl">
                    <Link href={localizedHref(locale, '/signup')} onClick={() => setMobileOpen(false)}>
                      {dict.signup}
                    </Link>
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2 border-t border-border/70 pt-4">
                  {(Object.entries(localeInfo) as [Locale, (typeof localeInfo)[Locale]][]).map(([key, info]) => (
                    <Link
                      key={key}
                      href={switchLocalePath(pathname, key)}
                      onClick={() => setMobileOpen(false)}
                      className={cn(
                        'rounded-full px-3 py-2 text-sm',
                        key === locale ? 'bg-primary text-primary-foreground' : 'bg-secondary',
                      )}
                    >
                      {info.nativeLabel}
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  )
}

function HeaderDropdown({ locale, title, menu }: { locale: Locale; title: string; menu: Dictionary['menu']['shop'] }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="rounded-full px-4">
          {title}
          <ChevronDown className="ms-2 h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-[320px] rounded-3xl p-3">
        <DropdownMenuLabel className="text-base">{menu.label}</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <div className="grid gap-2 pt-1">
          {menu.items?.map((item) => (
            <DropdownMenuItem key={item.href} asChild className="rounded-2xl p-0 focus:bg-transparent">
              <Link href={localizedHref(locale, item.href)} className="block rounded-2xl px-4 py-3 hover:bg-secondary">
                <span className="block font-medium">{item.label}</span>
                <span className="mt-1 block text-xs text-muted-foreground">{item.description}</span>
              </Link>
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

function MobileGroup({
  locale,
  title,
  items,
  onClose,
}: {
  locale: Locale
  title: string
  items: NonNullable<Dictionary['menu']['shop']['items']>
  onClose: () => void
}) {
  return (
    <div>
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">{title}</h3>
      <div className="grid gap-2">
        {items.map((item) => (
          <Link
            key={item.href}
            href={localizedHref(locale, item.href)}
            onClick={onClose}
            className="rounded-2xl border border-border bg-card px-4 py-3"
          >
            <span className="block font-medium">{item.label}</span>
            <span className="mt-1 block text-sm text-muted-foreground">{item.description}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
