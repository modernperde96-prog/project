import { partnerCards, Dictionary, Locale } from '@/lib/i18n'
import { cn } from '@/lib/utils'

export function PartnersSection({ locale, dict, compact = false }: { locale: Locale; dict: Dictionary; compact?: boolean }) {
  const cards = compact ? partnerCards.slice(0, 4) : partnerCards
  const showcaseLabel = locale === 'ar' ? 'عرض العلامة' : locale === 'ku' ? 'پیشاندانی براند' : locale === 'tr' ? 'Marka vitrini' : 'Brand showcase'

  return (
    <section className={cn('bg-secondary/35', compact ? 'py-24' : 'py-20')} id="partners">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">{dict.home.partners.eyebrow}</p>
          <h2 className="mt-3 text-3xl font-serif font-bold md:text-4xl">{compact ? dict.home.partners.title : dict.pages.partners.title}</h2>
          <p className="mt-4 text-lg text-muted-foreground">{compact ? dict.home.partners.description : dict.pages.partners.description}</p>
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {cards.map((partner, index) => (
            <article key={partner.name} className="group rounded-[1.75rem] border border-border bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-xl">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-primary/75 text-xl font-bold text-primary-foreground shadow-lg shadow-primary/20">
                  {partner.initials}
                </div>
                <div>
                  <h3 className="text-lg font-semibold">{partner.name}</h3>
                  <p className="text-sm text-muted-foreground">{partner.tag}</p>
                </div>
              </div>

              <div className="mt-6 rounded-[1.5rem] border border-dashed border-primary/20 bg-secondary/60 p-5">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{showcaseLabel}</span>
                  <span className="font-medium text-primary">0{index + 1}</span>
                </div>
                <div className="mt-4 flex h-24 items-center justify-center rounded-[1.25rem] bg-background">
                  <span className="text-2xl font-bold tracking-[0.3em] text-foreground/85">{partner.initials}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
