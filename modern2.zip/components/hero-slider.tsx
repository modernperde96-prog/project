"use client"

import Link from 'next/link'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowRight, ChevronLeft, ChevronRight, Pause, Play, Sparkles, Wand2, MonitorPlay, GalleryVerticalEnd } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { BeforeAfterSlider } from '@/components/before-after-slider'
import { BrandLogo } from '@/components/brand-logo'
import { cn } from '@/lib/utils'
import { Dictionary, Locale, getDir, localizePath } from '@/lib/i18n'

interface HeroSliderProps {
  locale: Locale
  dict: Dictionary
}

export function HeroSlider({ locale, dict }: HeroSliderProps) {
  const slides = useMemo(() => dict.hero.slides, [dict])
  const [currentSlide, setCurrentSlide] = useState(0)
  const [direction, setDirection] = useState(1)
  const [playing, setPlaying] = useState(true)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const dir = getDir(locale)

  const restart = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current)
    if (playing) {
      timerRef.current = setInterval(() => {
        setDirection(1)
        setCurrentSlide((value) => (value + 1) % slides.length)
      }, 7000)
    }
  }, [playing, slides.length])

  useEffect(() => {
    restart()
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [restart])

  const current = slides[currentSlide]
  const compareWords = {
    layered: locale === 'ar' ? 'طبقات' : locale === 'ku' ? 'توێژە' : locale === 'tr' ? 'Katman' : 'Layered',
    balanced: locale === 'ar' ? 'توازن' : locale === 'ku' ? 'هاوسەنگ' : locale === 'tr' ? 'Dengeli' : 'Balanced',
    premium: locale === 'ar' ? 'فاخر' : locale === 'ku' ? 'لوکس' : locale === 'tr' ? 'Premium' : 'Premium',
    video: locale === 'ar' ? 'سلايدر فيديو' : locale === 'ku' ? 'سلایدی ڤیدیۆ' : locale === 'tr' ? 'Video slider' : 'Video slider',
    reel: locale === 'ar' ? 'عرض الهوية' : locale === 'ku' ? 'ڕێلی براند' : locale === 'tr' ? 'Marka gösterimi' : 'Brand reel',
    preview: locale === 'ar' ? 'معاينة الهوية' : locale === 'ku' ? 'پێشبینینی براند' : locale === 'tr' ? 'Marka önizleme' : 'Branded preview',
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-secondary/40">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute end-0 top-0 h-[28rem] w-[28rem] rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute start-0 bottom-0 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="container relative mx-auto px-4 py-8 lg:py-12">
        <div className="grid min-h-[calc(100vh-13rem)] items-center gap-10 lg:grid-cols-[1.03fr_0.97fr] lg:gap-14">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={current.id + '-content'}
              custom={direction}
              initial={{ opacity: 0, x: direction > 0 ? 32 : -32 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: direction > 0 ? -32 : 32 }}
              transition={{ duration: 0.42 }}
              className="space-y-6"
            >
              <span className="inline-flex items-center gap-3 rounded-full border border-primary/20 bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
                <span className="h-2 w-2 rounded-full bg-primary" />
                {dict.hero.eyebrow}
              </span>

              <div>
                <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{current.badge}</p>
                <h1 className="max-w-2xl text-4xl font-serif font-bold leading-tight md:text-5xl lg:text-6xl">{current.title}</h1>
                <p className="mt-5 max-w-2xl text-lg leading-8 text-muted-foreground">{current.description}</p>
              </div>

              <div className="flex flex-wrap gap-3">
                {current.chips.map((chip) => (
                  <span key={chip} className="rounded-full border border-border bg-card px-4 py-2 text-sm">
                    {chip}
                  </span>
                ))}
              </div>

              <div className="flex flex-wrap gap-4 pt-2">
                <Button size="lg" asChild className="rounded-full px-6">
                  <Link href={localizePath(locale, current.primary.href)}>
                    {current.primary.label}
                    <ArrowRight className={cn('h-4 w-4', dir === 'rtl' ? 'mr-2 rotate-180' : 'ml-2')} />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="rounded-full px-6">
                  <Link href={localizePath(locale, current.secondary.href)}>{current.secondary.label}</Link>
                </Button>
              </div>
            </motion.div>
          </AnimatePresence>

          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={current.id + '-visual'}
              custom={direction}
              initial={{ opacity: 0, x: direction > 0 ? -32 : 32 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: direction > 0 ? 32 : -32 }}
              transition={{ duration: 0.42 }}
            >
              <SlideVisual locale={locale} dict={dict} type={current.type} compareWords={compareWords} />
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <div className="container relative mx-auto px-4 pb-10">
        <div className="inline-flex flex-wrap items-center gap-3 rounded-[2rem] border border-border bg-background/80 px-4 py-3 shadow-lg backdrop-blur-xl">
          <button onClick={() => { setDirection(-1); setCurrentSlide((value) => (value - 1 + slides.length) % slides.length); restart() }} className="rounded-full p-2 hover:bg-secondary" aria-label="Previous slide">
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            {slides.map((slide, index) => (
              <button
                key={slide.id}
                onClick={() => { setDirection(index > currentSlide ? 1 : -1); setCurrentSlide(index); restart() }}
                className={cn('h-2 rounded-full transition-all', index === currentSlide ? 'w-8 bg-primary' : 'w-2 bg-border hover:bg-muted-foreground')}
                aria-label={`Slide ${index + 1}`}
              />
            ))}
          </div>
          <button onClick={() => setPlaying((value) => !value)} className="rounded-full p-2 hover:bg-secondary" aria-label="Toggle autoplay">
            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          </button>
          <button onClick={() => { setDirection(1); setCurrentSlide((value) => (value + 1) % slides.length); restart() }} className="rounded-full p-2 hover:bg-secondary" aria-label="Next slide">
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  )
}

function SlideVisual({ locale, dict, type, compareWords }: { locale: Locale; dict: Dictionary; type: Dictionary['hero']['slides'][number]['type']; compareWords: Record<string, string> }) {
  if (type === 'compare') {
    return (
      <div className="relative">
        <BeforeAfterSlider
          beforeImage="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80"
          afterImage="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=80"
          beforeLabel={locale === 'ar' ? 'قبل' : locale === 'ku' ? 'پێش' : locale === 'tr' ? 'Önce' : 'Before'}
          afterLabel={locale === 'ar' ? 'بعد' : locale === 'ku' ? 'دوای' : locale === 'tr' ? 'Sonra' : 'After'}
          className="min-h-[24rem]"
        />
        <div className="absolute -bottom-5 left-1/2 flex -translate-x-1/2 gap-4 rounded-2xl border border-border bg-background/85 px-5 py-4 shadow-xl backdrop-blur-xl">
          {[
            { icon: Sparkles, label: compareWords.layered },
            { icon: Wand2, label: compareWords.balanced },
            { icon: GalleryVerticalEnd, label: compareWords.premium },
          ].map((item) => (
            <div key={item.label} className="min-w-[5rem] text-center">
              <item.icon className="mx-auto h-5 w-5 text-primary" />
              <span className="mt-2 block text-xs text-muted-foreground">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (type === 'video') {
    return (
      <div className="overflow-hidden rounded-[2rem] border border-border bg-card shadow-2xl">
        <div className="relative aspect-[16/10] overflow-hidden">
          <video
            autoPlay
            muted
            loop
            playsInline
            className="h-full w-full object-cover"
            poster="/modern-perde-logo.png"
          >
            <source src="/videos/modern-perde-brand.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
          <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
            <div>
              <p className="text-sm uppercase tracking-[0.2em] text-white/70">{compareWords.video}</p>
              <h3 className="mt-2 text-2xl font-serif font-bold text-white">{compareWords.reel}</h3>
            </div>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm text-white backdrop-blur-md">
              <MonitorPlay className="h-4 w-4" />
              {compareWords.preview}
            </span>
          </div>
        </div>
      </div>
    )
  }

  if (type === 'rails') {
    return (
      <div className="relative overflow-hidden rounded-[2rem] border border-border bg-card p-8 shadow-2xl">
        <div className="absolute inset-x-0 top-10 h-1 bg-gradient-to-r from-transparent via-primary/60 to-transparent" />
        <div className="absolute inset-x-0 top-24 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="absolute inset-x-0 top-36 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="space-y-5 pt-36">
          <BrandLogo href={localizePath(locale)} showText={false} />
          {dict.pages.rails.highlights.slice(0, 3).map((item, index) => (
            <div key={item.title} className="rounded-2xl bg-secondary/70 p-4">
              <p className="text-sm uppercase tracking-[0.18em] text-primary">0{index + 1}</p>
              <h3 className="mt-2 text-xl font-semibold">{item.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="overflow-hidden rounded-[2rem] border border-border bg-card shadow-2xl">
      <div className="grid gap-6 p-8 md:grid-cols-[0.9fr_1.1fr] md:items-center">
        <div>
          <BrandLogo href={localizePath(locale)} tagline={dict.brandTagline} />
          <div className="mt-6 grid gap-3">
            {[dict.nav.collections, dict.nav.rails, dict.nav.team].map((item) => (
              <div key={item} className="rounded-2xl bg-secondary/70 px-4 py-3 text-sm font-medium">
                {item}
              </div>
            ))}
          </div>
        </div>
        <div className="relative overflow-hidden rounded-[1.75rem] border border-border">
          <img
            src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80"
            alt="Modern Perde premium curtain styling"
            className="aspect-[4/3] h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/5 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-background/80 p-4 backdrop-blur-md">
            <p className="text-sm text-muted-foreground">Modern Perde</p>
            <p className="mt-1 font-semibold">{dict.home.cta.description}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
