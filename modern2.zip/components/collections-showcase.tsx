import Link from 'next/link'
import { Dictionary, Locale, localizePath } from '@/lib/i18n'

export function CollectionsShowcase({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const openLabel = locale === 'ar' ? 'افتح الصفحة' : locale === 'ku' ? 'کردنەوەی پەڕە' : locale === 'tr' ? 'Sayfayı aç' : 'Open page'
  return (
    <section className="py-24" id="collections">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">{dict.home.collections.eyebrow}</p>
          <h2 className="mt-3 text-3xl font-serif font-bold md:text-4xl">{dict.home.collections.title}</h2>
          <p className="mt-4 text-lg text-muted-foreground">{dict.home.collections.description}</p>
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {dict.home.collections.cards.map((card, index) => (
            <Link
              key={card.title}
              href={localizePath(locale, card.href)}
              className="group rounded-[1.75rem] border border-border bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-xl"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-lg font-bold text-primary">
                0{index + 1}
              </div>
              <h3 className="mt-5 text-xl font-semibold">{card.title}</h3>
              <p className="mt-3 text-muted-foreground">{card.desc}</p>
              <span className="mt-6 inline-flex rounded-full bg-secondary px-4 py-2 text-sm font-medium text-primary">{openLabel}</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
