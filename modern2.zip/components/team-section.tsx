import Link from 'next/link'
import { teamMembers, Dictionary, Locale, localizePath } from '@/lib/i18n'
import { Button } from '@/components/ui/button'

export function TeamSection({ locale, dict, compact = false }: { locale: Locale; dict: Dictionary; compact?: boolean }) {
  const members = compact ? teamMembers.slice(0, 3) : teamMembers

  return (
    <section className="py-24" id="team">
      <div className="container mx-auto px-4">
        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div className="max-w-3xl">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary">{dict.home.team.eyebrow}</p>
            <h2 className="mt-3 text-3xl font-serif font-bold md:text-4xl">{compact ? dict.home.team.title : dict.pages.team.title}</h2>
            <p className="mt-4 text-lg text-muted-foreground">{compact ? dict.home.team.description : dict.pages.team.description}</p>
          </div>
          {compact ? (
            <Button asChild variant="outline" className="rounded-full px-6">
              <Link href={localizePath(locale, '/team')}>{dict.home.team.cta}</Link>
            </Button>
          ) : null}
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-2 xl:grid-cols-4">
          {members.map((member, index) => (
            <article key={member.name} className="rounded-[1.8rem] border border-border bg-card p-6 shadow-sm">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-xl font-bold text-primary">
                {member.name
                  .split(' ')
                  .map((part) => part[0])
                  .join('')}
              </div>
              <p className="mt-5 text-xs uppercase tracking-[0.22em] text-muted-foreground">0{index + 1}</p>
              <h3 className="mt-2 text-xl font-semibold">{member.name}</h3>
              <p className="mt-1 text-sm font-medium text-primary">{member.role[locale]}</p>
              <p className="mt-4 text-muted-foreground">{member.bio[locale]}</p>
            </article>
          ))}
        </div>

        {!compact ? (
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {dict.pages.team.values.map((value) => (
              <div key={value.title} className="rounded-[1.5rem] border border-border bg-secondary/55 p-6">
                <h3 className="text-lg font-semibold">{value.title}</h3>
                <p className="mt-3 text-muted-foreground">{value.text}</p>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </section>
  )
}
