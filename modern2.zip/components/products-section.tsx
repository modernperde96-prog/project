"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"

const filters = [
  { id: "all", label: "All" },
  { id: "curtain", label: "Curtains" },
  { id: "sheer", label: "Sheers" },
  { id: "rail", label: "Rails" },
  { id: "accessory", label: "Accessories" },
]

const products = [
  {
    id: 1,
    category: "curtain",
    badge: "Best seller",
    title: "Royal Velvet Curtain",
    subtitle: "Layered luxury set",
    price: "$180",
    image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 2,
    category: "sheer",
    badge: "New",
    title: "Soft Light Sheer",
    subtitle: "Airy daytime elegance",
    price: "$95",
    image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 3,
    category: "rail",
    badge: "Modern",
    title: "Black Track Rail",
    subtitle: "Smooth premium movement",
    price: "$70",
    image: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 4,
    category: "accessory",
    badge: "Detail",
    title: "Premium Tieback Set",
    subtitle: "Elegant finishing touch",
    price: "$28",
    image: "https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 5,
    category: "curtain",
    badge: "Hotel line",
    title: "Grand Blackout Panel",
    subtitle: "Deep privacy coverage",
    price: "$140",
    image: "https://images.unsplash.com/photo-1460317442991-0ec209397118?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 6,
    category: "sheer",
    badge: "Minimal",
    title: "Pearl White Voile",
    subtitle: "Bright refined texture",
    price: "$88",
    image: "https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 7,
    category: "rail",
    badge: "Track system",
    title: "Ceiling Rail Pro",
    subtitle: "Clean hidden installation",
    price: "$82",
    image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 8,
    category: "accessory",
    badge: "Luxury",
    title: "Decor Ring Set",
    subtitle: "Strong polished detail",
    price: "$34",
    image: "https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=900&q=80",
  },
]

export function ProductsSection() {
  const [activeFilter, setActiveFilter] = useState("all")

  const filteredProducts =
    activeFilter === "all"
      ? products
      : products.filter((p) => p.category === activeFilter)

  return (
    <section id="collections" className="py-24">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 text-sm uppercase tracking-wider text-primary font-medium"
            >
              <span className="w-8 h-px bg-primary" />
              Featured collections
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl md:text-4xl font-serif font-bold mt-3"
            >
              Modern Perde best sellers
            </motion.h2>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="flex flex-wrap gap-2"
          >
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-medium transition-all",
                  activeFilter === filter.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary hover:bg-secondary/80"
                )}
              >
                {filter.label}
              </button>
            ))}
          </motion.div>
        </div>

        <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((product) => (
              <motion.article
                key={product.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="group bg-card rounded-3xl overflow-hidden border border-border hover:border-primary/20 transition-colors"
              >
                <div className="relative aspect-[0.92] overflow-hidden">
                  <div
                    className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105"
                    style={{ backgroundImage: `url(${product.image})` }}
                  />
                  <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-background/90 backdrop-blur-sm text-xs font-medium">
                    {product.badge}
                  </span>
                </div>
                <div className="p-5">
                  <div className="flex justify-between items-center text-sm text-muted-foreground mb-2">
                    <span>{product.subtitle}</span>
                    <span>#{String(product.id).padStart(2, "0")}</span>
                  </div>
                  <h3 className="font-semibold text-lg mb-3">{product.title}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold">{product.price}</span>
                    <button className="px-4 py-2 rounded-full bg-secondary text-sm font-medium hover:bg-primary hover:text-primary-foreground transition-colors">
                      Quick view
                    </button>
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  )
}
