import Image from "next/image"

export default function Loading() {
  return (
    <div className="fixed inset-0 z-[130] flex items-center justify-center bg-background px-6">
      <div className="text-center">
        <div className="relative mx-auto mb-6 h-28 w-28 overflow-hidden rounded-[2rem] border border-border bg-card shadow-xl shadow-primary/10">
          <Image
            src="/modern-perde-logo.png"
            alt="Modern Perde"
            fill
            priority
            sizes="112px"
            className="object-cover"
          />
        </div>
        <h2 className="text-2xl font-serif font-bold">Modern Perde</h2>
        <p className="mt-2 text-sm text-muted-foreground">Preparing your page...</p>
        <div className="mt-6 flex items-center justify-center gap-3">
          <span className="block h-2.5 w-2.5 animate-pulse rounded-full bg-primary" />
          <span className="block h-2.5 w-2.5 animate-pulse rounded-full bg-primary [animation-delay:0.2s]" />
          <span className="block h-2.5 w-2.5 animate-pulse rounded-full bg-primary [animation-delay:0.4s]" />
        </div>
      </div>
    </div>
  )
}
