import { notFound } from 'next/navigation'
import { HeroSlider } from '@/components/hero-slider'
import { CollectionsShowcase } from '@/components/collections-showcase'
import { PartnersSection } from '@/components/partners-section'
import { TeamSection } from '@/components/team-section'
import { AboutSection } from '@/components/about-section'
import { ContactSection } from '@/components/contact-section'
import { SiteShell } from '@/components/site-shell'
import { getDictionary, isLocale, type Locale } from '@/lib/i18n'

export default async function HomePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  if (!isLocale(locale)) notFound()
  const currentLocale = locale as Locale

  const dict = getDictionary(currentLocale)

  return (
    <SiteShell locale={currentLocale} dict={dict}>
      <HeroSlider locale={currentLocale} dict={dict} />
      <CollectionsShowcase locale={currentLocale} dict={dict} />
      <PartnersSection locale={currentLocale} dict={dict} compact />
      <TeamSection locale={currentLocale} dict={dict} compact />
      <AboutSection locale={currentLocale} dict={dict} compact />
      <ContactSection locale={currentLocale} dict={dict} />
    </SiteShell>
  )
}
