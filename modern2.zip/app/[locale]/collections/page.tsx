import Link from 'next/link'
import { notFound } from 'next/navigation'
import { PageHero } from '@/components/page-hero'
import { SiteShell } from '@/components/site-shell'
import { getDictionary, isLocale, localizePath, type Locale } from '@/lib/i18n'
import { Button } from '@/components/ui/button'

export default async function CollectionsPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  if (!isLocale(locale)) notFound()
  const currentLocale = locale as Locale
  const dict = getDictionary(currentLocale)

  return (
    <SiteShell locale={currentLocale} dict={dict}>
      <PageHero
        eyebrow={dict.nav.collections}
        title={dict.pages.collections.title}
        description={dict.pages.collections.description}
        actions={
          <>
            <Button asChild className="rounded-full px-6"><Link href={localizePath(currentLocale, '/contact')}>{dict.home.cta.primary}</Link></Button>
            <Button asChild variant="outline" className="rounded-full px-6"><Link href={localizePath(currentLocale, '/rails')}>{dict.nav.rails}</Link></Button>
          </>
        }
      />

      <section className="py-20" id="curtains">
        <div className="container mx-auto px-4">
          <div className="grid gap-6 lg:grid-cols-2">
            {dict.pages.collections.sections.map((section) => (
              <div key={section.title} className="rounded-[2rem] border border-border bg-card p-8 shadow-sm">
                <h2 className="text-2xl font-serif font-bold">{section.title}</h2>
                <div className="mt-6 grid gap-4">
                  {section.items.map((item) => (
                    <div key={item.title} className="rounded-[1.5rem] border border-border bg-secondary/55 p-5" id={item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}>
                      <h3 className="text-lg font-semibold">{item.title}</h3>
                      <p className="mt-2 text-muted-foreground">{item.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10 grid gap-5 md:grid-cols-3">
            <img src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=900&q=80" alt="Sheer curtains" className="aspect-[4/5] w-full rounded-[1.8rem] object-cover" id="sheers" />
            <img src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80" alt="Luxury curtains" className="aspect-[4/5] w-full rounded-[1.8rem] object-cover" />
            <img src="https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=900&q=80" alt="Blackout curtains" className="aspect-[4/5] w-full rounded-[1.8rem] object-cover" id="blackout" />
          </div>
        </div>
      </section>
    </SiteShell>
  )
}
