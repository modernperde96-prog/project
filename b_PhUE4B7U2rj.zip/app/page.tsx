import { SiteHeader } from "@/components/site-header"
import { HeroSlider } from "@/components/hero-slider"
import { TrustStrip } from "@/components/trust-strip"
import { CategoriesSection } from "@/components/categories-section"
import { ProductsSection } from "@/components/products-section"
import { CustomDesignSection } from "@/components/custom-design-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { AboutSection } from "@/components/about-section"
import { SiteFooter } from "@/components/site-footer"

export default function HomePage() {
  return (
    <main className="min-h-screen" id="home">
      <SiteHeader />
      <HeroSlider />
      <TrustStrip />
      <CategoriesSection />
      <ProductsSection />
      <CustomDesignSection />
      <TestimonialsSection />
      <AboutSection />
      <SiteFooter />
    </main>
  )
}
