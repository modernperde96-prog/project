"use client"

import { motion } from "framer-motion"
import { Award, MapPin, Calendar, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

const stats = [
  { icon: Award, value: "10+", label: "Years of experience" },
  { icon: MapPin, value: "3", label: "Showroom locations" },
  { icon: Calendar, value: "2500+", label: "Projects completed" },
  { icon: Sparkles, value: "120+", label: "Fabric selections" },
]

export function AboutSection() {
  return (
    <section id="about" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image Grid */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="space-y-4">
              <div className="aspect-[3/4] rounded-3xl overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=600&q=80"
                  alt="Modern Perde showroom"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="glass rounded-2xl p-5">
                <span className="block text-3xl font-bold text-primary">2500+</span>
                <span className="text-sm text-muted-foreground">Happy clients</span>
              </div>
            </div>
            <div className="space-y-4 pt-8">
              <div className="glass rounded-2xl p-5">
                <span className="block text-3xl font-bold text-primary">10+</span>
                <span className="text-sm text-muted-foreground">Years of excellence</span>
              </div>
              <div className="aspect-[3/4] rounded-3xl overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80"
                  alt="Modern Perde fabrics"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </motion.div>

          {/* Content */}
          <div>
            <motion.span
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 text-sm uppercase tracking-wider text-primary font-medium"
            >
              <span className="w-8 h-px bg-primary" />
              About Modern Perde
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl md:text-4xl font-serif font-bold mt-3 mb-6"
            >
              A trusted name in luxury curtains and window styling
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-muted-foreground mb-6"
            >
              Modern Perde was founded with one purpose: to bring refined, high-quality
              window treatments to homes and businesses across the region. We believe
              that curtains are not just functional—they are part of your interior story.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="text-muted-foreground mb-8"
            >
              From premium velvet drapes to motorized rail systems, our team combines
              craftsmanship with modern design to deliver solutions that elevate every
              space. With multiple showrooms and a growing collection, we continue
              to set the standard for luxury window styling.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8"
            >
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <stat.icon className="h-6 w-6 mx-auto text-primary mb-2" />
                  <span className="block text-2xl font-bold">{stat.value}</span>
                  <span className="text-xs text-muted-foreground">{stat.label}</span>
                </div>
              ))}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap gap-4"
            >
              <Button size="lg" asChild>
                <a href="#contact">Visit Showroom</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#collections">Browse Collection</a>
              </Button>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}
