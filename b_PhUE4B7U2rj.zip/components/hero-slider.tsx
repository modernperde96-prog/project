"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Play, Pause, Sparkles, Sun, Gem, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { BeforeAfterSlider } from "@/components/before-after-slider"
import { cn } from "@/lib/utils"

interface SlideContent {
  id: string
  type: "compare" | "video" | "moodboard" | "rails" | "process" | "brand"
  badge: string
  title: string
  description: string
  primaryCta: { text: string; href: string }
  secondaryCta: { text: string; href: string }
  features?: { icon: string; text: string }[]
}

const slides: SlideContent[] = [
  {
    id: "compare",
    type: "compare",
    badge: "Before & After Styling",
    title: "See how curtains transform the entire room",
    description: "Drag the slider to compare the same window before and after Modern Perde styling with a brighter, cleaner and more premium finish.",
    primaryCta: { text: "Explore Collection", href: "#collections" },
    secondaryCta: { text: "Send Your Window", href: "#custom-design" },
    features: [
      { icon: "sparkle", text: "Soft layered look" },
      { icon: "sun", text: "Better natural light" },
      { icon: "gem", text: "Luxury final mood" },
    ],
  },
  {
    id: "moodboard",
    type: "moodboard",
    badge: "Fabric Moodboard",
    title: "Choose the curtain mood before you choose the fabric",
    description: "A softer approach with mood chips and finish cards makes your decision easier, while matching our luxury brand identity.",
    primaryCta: { text: "See Categories", href: "#categories" },
    secondaryCta: { text: "Ask for Advice", href: "#contact" },
    features: [
      { icon: "sparkle", text: "120+ fabric directions" },
      { icon: "sun", text: "Custom window sizing" },
      { icon: "gem", text: "Luxury final finish" },
    ],
  },
  {
    id: "rails",
    type: "rails",
    badge: "Rail & Hardware Focus",
    title: "The rail system should feel premium too",
    description: "Not only curtains. This slide uses a cleaner product spotlight style with design details, hardware lines and a more technical luxury feeling.",
    primaryCta: { text: "Explore Rails", href: "#categories" },
    secondaryCta: { text: "Request Full Setup", href: "#custom-design" },
    features: [
      { icon: "sparkle", text: "Smoother movement" },
      { icon: "sun", text: "Cleaner installation" },
      { icon: "gem", text: "Better final detail" },
    ],
  },
  {
    id: "process",
    type: "process",
    badge: "Custom Service Process",
    title: "Send a room photo. Get direction faster.",
    description: "A process slide gives the hero a different style and clearly explains how customers can work with your shop from phone or desktop.",
    primaryCta: { text: "Start Your Request", href: "#custom-design" },
    secondaryCta: { text: "Talk to Team", href: "#contact" },
  },
  {
    id: "brand",
    type: "brand",
    badge: "Brand Signature",
    title: "A bold final slide built around your logo and brand",
    description: "The last slide uses a clean premium brand layout, helping the hero feel complete without repeating the same before-and-after logic.",
    primaryCta: { text: "Shop Modern Perde", href: "#collections" },
    secondaryCta: { text: "Visit Showroom", href: "#contact" },
  },
]

const FeatureIcon = ({ icon }: { icon: string }) => {
  switch (icon) {
    case "sparkle":
      return <Sparkles className="h-4 w-4" />
    case "sun":
      return <Sun className="h-4 w-4" />
    case "gem":
      return <Gem className="h-4 w-4" />
    default:
      return <Sparkles className="h-4 w-4" />
  }
}

export function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)
  const [direction, setDirection] = useState(0)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const startAutoPlay = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    intervalRef.current = setInterval(() => {
      setDirection(1)
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 8000)
  }, [])

  const stopAutoPlay = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
  }, [])

  useEffect(() => {
    if (isPlaying) {
      startAutoPlay()
    } else {
      stopAutoPlay()
    }
    return () => stopAutoPlay()
  }, [isPlaying, startAutoPlay, stopAutoPlay])

  const goToSlide = (index: number) => {
    setDirection(index > currentSlide ? 1 : -1)
    setCurrentSlide(index)
    if (isPlaying) startAutoPlay()
  }

  const nextSlide = () => {
    setDirection(1)
    setCurrentSlide((prev) => (prev + 1) % slides.length)
    if (isPlaying) startAutoPlay()
  }

  const prevSlide = () => {
    setDirection(-1)
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
    if (isPlaying) startAutoPlay()
  }

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 100 : -100,
      opacity: 0,
      scale: 0.98,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 100 : -100,
      opacity: 0,
      scale: 0.98,
    }),
  }

  const slide = slides[currentSlide]

  return (
    <section className="relative min-h-[calc(100vh-80px)] overflow-hidden bg-gradient-to-br from-background via-background to-secondary/30">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-to-bl from-primary/5 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-gradient-to-tr from-primary/5 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 py-8 lg:py-16">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={slide.id}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
            className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center min-h-[calc(100vh-200px)]"
          >
            {/* Content Side */}
            <div className="order-2 lg:order-1 space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1, duration: 0.5 }}
              >
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium">
                  <span className="w-2 h-2 rounded-full bg-primary animate-pulse-ring" />
                  {slide.badge}
                </span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold leading-tight text-balance"
              >
                {slide.title}
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.5 }}
                className="text-lg text-muted-foreground max-w-xl leading-relaxed"
              >
                {slide.description}
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.5 }}
                className="flex flex-wrap gap-4 pt-2"
              >
                <Button size="lg" className="group" asChild>
                  <a href={slide.primaryCta.href}>
                    {slide.primaryCta.text}
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </a>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <a href={slide.secondaryCta.href}>{slide.secondaryCta.text}</a>
                </Button>
              </motion.div>

              {slide.features && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 0.5 }}
                  className="flex flex-wrap gap-3 pt-4"
                >
                  {slide.features.map((feature, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border text-sm"
                    >
                      <FeatureIcon icon={feature.icon} />
                      <span>{feature.text}</span>
                    </div>
                  ))}
                </motion.div>
              )}
            </div>

            {/* Visual Side */}
            <div className="order-1 lg:order-2">
              <SlideVisual slide={slide} />
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Slider Controls */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20">
        <div className="glass rounded-2xl px-6 py-4 flex items-center gap-6">
          <button
            onClick={prevSlide}
            className="p-2 rounded-full hover:bg-primary/10 transition-colors"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center gap-2 text-sm">
              <span className="font-bold text-primary">
                {String(currentSlide + 1).padStart(2, "0")}
              </span>
              <span className="text-muted-foreground">/</span>
              <span className="text-muted-foreground">
                {String(slides.length).padStart(2, "0")}
              </span>
            </div>

            <div className="flex gap-2">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={cn(
                    "w-2 h-2 rounded-full transition-all duration-300",
                    index === currentSlide
                      ? "w-8 bg-primary"
                      : "bg-border hover:bg-muted-foreground"
                  )}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2 rounded-full hover:bg-primary/10 transition-colors"
            aria-label={isPlaying ? "Pause slideshow" : "Play slideshow"}
          >
            {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          </button>

          <button
            onClick={nextSlide}
            className="p-2 rounded-full hover:bg-primary/10 transition-colors"
            aria-label="Next slide"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  )
}

function SlideVisual({ slide }: { slide: SlideContent }) {
  switch (slide.type) {
    case "compare":
      return <CompareVisual />
    case "moodboard":
      return <MoodboardVisual />
    case "rails":
      return <RailsVisual />
    case "process":
      return <ProcessVisual />
    case "brand":
      return <BrandVisual />
    default:
      return <CompareVisual />
  }
}

function CompareVisual() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2, duration: 0.6 }}
      className="relative"
    >
      <BeforeAfterSlider
        beforeImage="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80"
        afterImage="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80"
        beforeLabel="Before"
        afterLabel="After"
      />
      <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 glass rounded-xl px-6 py-3 flex gap-6">
        <div className="text-center">
          <span className="block text-xl font-bold text-primary">01</span>
          <span className="text-xs text-muted-foreground">Layered styling</span>
        </div>
        <div className="text-center">
          <span className="block text-xl font-bold text-primary">02</span>
          <span className="text-xs text-muted-foreground">Balanced light</span>
        </div>
        <div className="text-center">
          <span className="block text-xl font-bold text-primary">03</span>
          <span className="text-xs text-muted-foreground">Premium finish</span>
        </div>
      </div>
    </motion.div>
  )
}

function MoodboardVisual() {
  const swatches = [
    "bg-[#f5f0e8]",
    "bg-[#d4c4b0]",
    "bg-[#8b7355]",
    "bg-[#2c2c2c]",
  ]
  const tags = ["Sheer", "Blackout", "Layered", "Wave fold"]

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2, duration: 0.6 }}
      className="glass rounded-3xl p-6 space-y-4"
    >
      <div className="flex gap-3">
        {swatches.map((color, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 + i * 0.1 }}
            className={cn("w-12 h-12 rounded-xl shadow-md", color)}
          />
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag, i) => (
          <span
            key={i}
            className="px-3 py-1 rounded-full bg-secondary text-sm"
          >
            {tag}
          </span>
        ))}
      </div>
      <div className="aspect-video rounded-2xl overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80"
          alt="Curtain styling"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="grid grid-cols-3 gap-4 pt-2">
        <div className="text-center">
          <span className="block text-2xl font-bold">120+</span>
          <span className="text-xs text-muted-foreground">fabric directions</span>
        </div>
        <div className="text-center">
          <span className="block text-2xl font-bold">Custom</span>
          <span className="text-xs text-muted-foreground">window sizing</span>
        </div>
        <div className="text-center">
          <span className="block text-2xl font-bold">Luxury</span>
          <span className="text-xs text-muted-foreground">final finish</span>
        </div>
      </div>
    </motion.div>
  )
}

function RailsVisual() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2, duration: 0.6 }}
      className="glass rounded-3xl p-8 relative overflow-hidden"
    >
      {/* Rail lines */}
      <div className="absolute top-8 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
      <div className="absolute top-20 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="absolute top-32 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-border to-transparent" />

      <div className="pt-40 space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <span className="text-primary font-bold">MP</span>
          </div>
          <span className="font-medium">Modern Perde System</span>
        </div>

        <div className="grid gap-4">
          {[
            { num: "01", text: "Smoother movement" },
            { num: "02", text: "Cleaner installation" },
            { num: "03", text: "Better final detail" },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
              className="flex items-center gap-4 p-4 rounded-xl bg-secondary/50"
            >
              <span className="text-xl font-bold text-primary">{item.num}</span>
              <span>{item.text}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}

function ProcessVisual() {
  const steps = [
    { num: "01", title: "Send photo", desc: "Window or room image" },
    { num: "02", title: "Choose mood", desc: "Color, fold and light level" },
    { num: "03", title: "Get proposal", desc: "Clear curtain direction" },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2, duration: 0.6 }}
      className="space-y-4"
    >
      {steps.map((step, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 + i * 0.15 }}
          className="glass rounded-2xl p-6 flex gap-4"
        >
          <span className="text-3xl font-bold text-primary">{step.num}</span>
          <div>
            <h3 className="font-semibold text-lg">{step.title}</h3>
            <p className="text-muted-foreground text-sm">{step.desc}</p>
          </div>
        </motion.div>
      ))}
    </motion.div>
  )
}

function BrandVisual() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2, duration: 0.6 }}
      className="glass rounded-3xl p-8 text-center space-y-6"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.4, type: "spring" }}
        className="w-24 h-24 mx-auto rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center text-white text-3xl font-bold shadow-lg shadow-primary/30"
      >
        MP
      </motion.div>
      <div>
        <h3 className="text-3xl font-serif font-bold">Modern Perde</h3>
        <div className="flex flex-wrap justify-center gap-2 mt-4">
          {["Luxury curtains", "Custom rails", "Window styling"].map((chip, i) => (
            <span
              key={i}
              className="px-3 py-1 rounded-full bg-secondary text-sm"
            >
              {chip}
            </span>
          ))}
        </div>
      </div>
      <div className="aspect-video rounded-2xl overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80"
          alt="Modern Perde styling"
          className="w-full h-full object-cover"
        />
      </div>
    </motion.div>
  )
}
